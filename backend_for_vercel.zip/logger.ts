const winston = require('winston');
const path = require('path');

const logger = winston.createLogger({
  level: 'info',
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.json()
  ),
  transports: [
    // Write all errors to stderr.log
    new winston.transports.File({ 
      filename: path.join(__dirname, '../logs/stderr.log'),
      level: 'error'
    }),
    // Write all logs to stdout
    new winston.transports.Console({
      format: winston.format.combine(
        winston.format.colorize(),
        winston.format.simple()
      )
    })
  ]
});

module.exports = logger;
